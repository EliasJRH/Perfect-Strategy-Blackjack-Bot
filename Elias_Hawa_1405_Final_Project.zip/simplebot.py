starting_cash = 1000
cash = starting_cash
